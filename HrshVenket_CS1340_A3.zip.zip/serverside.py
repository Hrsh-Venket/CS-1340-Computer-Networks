import socket 

serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

host = 'localhost'
port = 50000

serverSocket.bind((host, port))

# 1. What is the total number of CS credits needed to complete the 4 year BSc Hons degree in CS?
# 2. Could you provide a breakdown of CS credits
# 3. What are the core courses?
# 4. What are the basic Science and math courses?
# 5. If I have not taken math in 11th and 12th, how can I do CS?
# 6. Can you provide a breakdown of Non-Academic credits?
# 7. What is an example path for the program?
# 8. Can you provide a breakdown of Academic credits?
# 9. What are the computational thinking courses?
# 10. What are the systems and software courses?

basic_science_math_courses = [
    "P&S",
    "Linear Algebra",
    "Calculus",
    "Physics",
    "Biology"    
]

computational_thinking_courses = [
    "Introduction to Computer Science",
    "Discrete Mathematics",
    "Data Structures and Algorithms",
    "Introduction to Machine Learning",
    "Data Science and Management",
    "Theory of Computation",
    "Design and Analysis of Algorithms",
    "Programming Languages and Translation",
    "Information Security"
]

systems_software_courses = [
    "Computer Organization and Systems",
    "Design Practices in CS",
    "Computer Networks",
    "Embedded Systems"
]

core_courses = [
    basic_science_math_courses,
    computational_thinking_courses,
    systems_software_courses,
    "Capstone Project"
]

example_path = [
    "Semester 1: Calculus", 
    "Semester 2: Introduction to Computer Science, and Discrete Mathematics",
    "Semester 3: Probability and Statistics, Linear Algebra, and Data Structures and Algorithms",
    "Semester 4: Theory of Computation, and Computer Organization and Systems",
    "Semester 5: Design Practices in CS, Introduction to Machine Learning, Computer Networks, Information Security (2 credits)",
    "Semester 6: Design and Analysis of Algorithms, Data Science and Management, Embedded Systems, and Data Science and Management",
    "Semester 7: Programming Languages and Translation, and Capstone Project",
    "Semester 8: -"
]

while True:
    serverSocket.listen(4)
    print("Server is waiting for a connection ....")

    clientSocket, address = serverSocket.accept()
    print(f"connection from: {address}")
    
    intro = "Welcome to the CS program at Ashoka University.\n Here are the questions you can ask:\n 1. What is the total number of CS credits needed to complete the 4 year BSc Hons degree in CS?\n 2. Could you provide a breakdown of CS credits\n 3. What are the core courses?\n 4. What are the basic Science and math courses?\n 5. If I have not taken math in 11th and 12th, how can I do CS?\n 6. Can you provide a breakdown of Non-Academic credits?\n 7. What is an example path for the program?\n 8. Can you provide a breakdown of Academic credits?\n 9. What are the computational thinking courses?\n 10. What are the systems and software courses?\n"
    clientSocket.send(intro.encode('utf-8'))

    while True:
        data = clientSocket.recv(1024)
        if not data:
            break

        question = int(data.decode('utf-8'))

        response_message = ""
        
        if question == 0:
            clientSocket.close()
        if question == 1:
            response_message = f"You need 150 credits to complete the 4 year BSc Hons degree in CS."
        elif question == 2: 
            response_message = f"You need 86 CS credits in total. 70 Core, 4 Project, and 12 Elective"
        elif question == 3:
            response_message = f"The core courses are {core_courses}"
        elif question == 4:
            response_message = f"The basic science and math courses are {basic_science_math_courses}"
        elif question == 5:
            response_message = f"You can take CS by first getting at least a B in both Quantitative Reasoning and Mathematical Thinking (FC 0306) and Calculus (MAT 1000)."
        elif question == 6:
            response_message = f"You need 6 Non-academic credits in total. 4 from co-curricular courses, and 2 from an internship."
        elif question == 7:
            response_message = f"An example path for the program is {example_path}"
        elif question == 8:
            response_message = f"You need 144 Academic credits in total. 36 FC, 86 CS, and 22 Open"
        elif question == 9:
            response_message = f"The computational thinking courses are {computational_thinking_courses}"
        elif question == 10:
            response_message = f"The systems and software courses are {systems_software_courses}"
        else:
            response_message = f"Invalid question number. Please choose a valid question."

        clientSocket.send(response_message.encode('utf-8'))

serverSocket.close()