import socket

clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serverHost = "localhost"
serverPort = 50000

clientSocket.connect((serverHost, serverPort))

intro = clientSocket.recv(1024).decode('utf-8')

print(f"{intro}")

while True:
    question = int(input("What question would you like to ask? Write 0 if you want to exit.\n"))
    if question == 0:
        clientSocket.close()
        break
    clientSocket.send(str(question).encode('utf-8'))
    result = clientSocket.recv(1024).decode('utf-8')
    print(f"Result: {result}")
